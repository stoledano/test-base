About : 
Screen2Avi is a free screen capturer capable to produce screencasts and screenshots

Installation + Settings : 
Screen2Avi is portable so you just have to unzip it.
From the "Screen" tab select the region (portion) of your screen that you want to capture
Now move to "Video" and select a compressor.
Valid options are "Microsoft Video 1", Lagarith and ffdshow (HuffYUV)
The last two options (free codecs) need installation for more informations visit our website
If you want to capture the audio too go to the "Audio" tab
From the "General" tab you can select the output of your screencasts and screenshots.
Detailed infos about the "General" settings can be found on our website as always.

Usage : 
Just hit the Record button to start recording and the stop button to stop recording.
By hitting the screenshot button you capture and save as bitmap (bmp) the desired screenshot.
You can take screenshots even if you are not recording

Problems : 
1) Slow/Fast Video and(or) Audio out of sync
Under Win7/Vista
a)Use Lagarith as video compressor
or b)Decrease the fps from video options (5-10 fps)
or c)Decrease the dimension of your capture window
or d)Disable Aero (yes this can be the problem !)
or e)All the above
Under XP
a)Use Lagarith as video compressor
or b)Decrease the fps from video options (5-10 fps)
or c)Decrease the dimension of your capture window
or d)All the above

2) I can not capture some windows (transparency problem)
Under Win7/Vista
a)Go to "General" and check the transparency option
or b)Enable aero
Under WinXP
Go to "General" and check the transparency option

3) Videos are not captured (overlay problem)
Under Win7/Vista/WinXp
a)Use Media Player Classic
b)Use VLC (tools -> preferences -> video -> disable overlay video output )
c)Disable Hardware Acceleration
Notice that all these solutions are ordered by importancy
If you do not understand how to do these settings please visit our website for more informations.

Special Thanks : 
Turbo Delphi (www.turboexplorer.com/delphi)
DSPack (www.progdigy.com)
JEDI VCL (www.delphi-jedi.org)
Crystal project (www.everaldo.com/crystal)

Visit our official website : www.trustfm.net
Official Screen2Avi Page :
http://www.trustfm.net/divx/SoftwareScreen2Avi.php
 
   