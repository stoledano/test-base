﻿
== INTRO ==========================================================================================
 Help make File Joiner available to more users by translating it into your native language.
 File Joiner uses text files to store strings so to translate you only need a text editor like
 Notepad or preferably Notepad++. If you're interested in helping translate File Joiner into
 your native language, and I sure hope you are, than please read instructions.


== INSTRUCTIONS ===================================================================================
 Instructions can be found here:

  www.igorware.com/file-joiner/translate


===================================================================================================
 If you have any questions you can email me at support@igorware.com
 Thank you for your support,
 Igor
